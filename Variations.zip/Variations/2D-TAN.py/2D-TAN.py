#Add this code 
!pip uninstall torch torchvision torchtext torchaudio --yes
!pip install torch==1.13.1 torchvision==0.14.1 torchtext==0.14.1 torchaudio==0.13.1

!pip install transformers

!python /content/episodic-memory/NLQ/2D-TAN/moment_localization/train.py --cfg /content/episodic-memory/NLQ/2D-TAN/experiments/ego4d/2D-TAN-40x40-K9L4-pool-window-std-sf.yaml --verbose